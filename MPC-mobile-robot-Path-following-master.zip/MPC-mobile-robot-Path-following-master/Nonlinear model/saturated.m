function b=saturated(min_,max_,a)   
    b=min(max_,max(min_,a));
end