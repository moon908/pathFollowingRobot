# MPC-mobile-robot-Path-following
Design and simulation model predictive control for path following with mobile robot.[slides](https://docs.google.com/presentation/d/1o4I801dG_9UP-g5VLKMtb7e7fcRZt5FgzvDBPB5F0ZY/edit?usp=sharing)
